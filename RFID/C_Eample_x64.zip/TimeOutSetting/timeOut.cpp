#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include "../is_d2xx.h"


int main(void)
{
	IS_HANDLE ftHandle;
	char SerialNumber[] = "RFID01";
	unsigned long readTimeOut = 0, writeTimeOut = 0;

	if (is_OpenSerialNumber(&ftHandle, SerialNumber, 115200) != IS_OK)
	{
		printf("USB To Serial �� ��� ���� ����\n");
		_getch();
		return -1;
	}


	if (is_GetTimeOut(ftHandle, &readTimeOut, &writeTimeOut) == IS_OK)
	{
		printf("Read Timeout : %d\n", readTimeOut);
		printf("Write Timeout : %d\n", writeTimeOut);
	}
	readTimeOut = 700;
	writeTimeOut = 300;
	if (is_SetTimeOut(ftHandle, readTimeOut, writeTimeOut) == IS_OK)
	{
		printf("���� �Ϸ�\n");
	}

	if (is_GetTimeOut(ftHandle, &readTimeOut, &writeTimeOut) == IS_OK)
	{
		printf("Read Timeout : %d\n", readTimeOut);
		printf("Write Timeout : %d\n", writeTimeOut);
	}
	_getch();
	return 0;
}
