#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include "../is_d2xx.h"


int main(void)
{
	IS_HANDLE ftHandle;
	char SerialNumber[] = "RFID01";
	//
	unsigned char wirteData[1024];
	unsigned short writeLength = 0;
	unsigned char readData[1024];
	unsigned short readLength = 0;
	unsigned char cmd1, cmd2;

	if (is_OpenSerialNumber(&ftHandle, SerialNumber, 115200) != IS_OK)
	{
		printf("USB To Serial �� ��� ���� ����\n");
		_getch();
		return -1;
	}

	while (1)
	{
		if (is_WriteCommand(ftHandle, CM1_COMMON, CMD2_COMMON_ALL_UID_READ + BUZZER_ON, writeLength, wirteData) == IS_OK)
		{
			//������ �۾����� ó�� �Ҷ� �����ϰ� ��� �Ҽ� �ֽ��ϴ�.
			if (is_ReadExCommand(ftHandle, &cmd1, &cmd2, &readLength, readData) == IS_OK)
			{
				int i;
				printf("Command1 = %x, Command2 =  %x\n", cmd1, cmd2);
				printf("UID : ");
				for (i = 0; i < readLength; i++)
				{
					printf("%x ", readData[i]);
				}
				printf("\n");
			}
		}
		Sleep(400);
		if (_kbhit())
			break;
		printf(".");

	}
	is_Close(ftHandle);
	_getch();
	return 0;
}
