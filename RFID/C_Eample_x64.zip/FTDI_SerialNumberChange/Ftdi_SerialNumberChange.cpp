#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include "../is_d2xx.h"


int main(void)
{
	IS_HANDLE ftHandle;
	char changeSerialNumber[] = "RFID01";
	char readSerialNumber[100];
	short usbnumber;

	if (is_GetDeviceNumber(&usbnumber) == IS_OK)
	{
		printf("FTDI USB To Serial ����� ���� : %d\n", usbnumber);
		if (is_GetSerialNumber(0, readSerialNumber) == IS_OK)
		{
			if (memcmp(changeSerialNumber, readSerialNumber, sizeof(changeSerialNumber) != 0))
			{
				if (is_SetSerialNumber(0, changeSerialNumber) == IS_OK)
				{
					printf(" USB To Serial Number �� ���� �Ͽ����ϴ�.\n");
					printf(" FTDI SerialNumber :  %s \n", changeSerialNumber);
				}
			}
			else
				printf(" FTDI SerialNumber :  %s \n", changeSerialNumber);
		}
	}
	
	_getch();
	return 0;	
}
