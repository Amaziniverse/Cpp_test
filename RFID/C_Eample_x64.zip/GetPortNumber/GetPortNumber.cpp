#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include "../is_d2xx.h"


int main(void)
{
	IS_HANDLE ftHandle;
	char SerialNumber[] = "RFID01";
	unsigned long portNumber;

	if (is_GetCOMPort_NoConnect(0, &portNumber) == IS_OK)
	{
		printf("COM Port : %d\n", portNumber);
	}

	if (is_OpenSerialNumber(&ftHandle, SerialNumber, 115200) != IS_OK)
	{
		printf("USB To Serial �� ��� ���� ����\n");
		_getch();
		return -1;
	}

	if (is_GetCOMPort(ftHandle, &portNumber) == IS_OK)
	{
		printf("COM Port : %d\n", portNumber);
	}
	_getch();
	return 0;
}
